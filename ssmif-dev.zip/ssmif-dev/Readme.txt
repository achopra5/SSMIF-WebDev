# SSMIF-WebDev - Quant Development Challenge Submission

Overview
This project is part of the **SSMIF Quant Development Challenge (Spring 2025)**. It is a **full-stack financial application** that:
- Fetches historical stock data from **Yahoo Finance**.
- Stores and processes data in **ClickHouse**.
- Provides **real-time portfolio performance insights** via a **React frontend**.
- Supports **portfolio optimization and risk analysis**.

---

## 📂 Project Structure
SSMIF-DEV/
│── ssmif-backend/               # FastAPI backend
│   ├── __pycache__/             # Compiled Python files
│   ├── fetch_stock_prices.py    # Stock data ingestion
│   ├── load_holdings.py         # Holdings ingestion
│   ├── main.py                  # API entry point
│── ssmif-frontend/              # React frontend
│   ├── node_modules/            # Dependencies
│   ├── public/                  # Static assets
│   │   ├── favicon.ico          
│   │   ├── index.html           # Main HTML file
│   │   ├── manifest.json        
│   ├── src/
│   │   ├── components/          # UI components
│   │   │   ├── CorrelationBox.js
│   │   │   ├── DailyReturnsChart.js
│   │   │   ├── HoldingsTable.js
│   │   │   ├── OptimizedPortfolio.js
│   │   │   ├── PortfolioChart.js
│   │   │   ├── PortfolioVsSP500.js
│   │   │   ├── RollingVolatilityChart.js
│   │   │   ├── SharpeRatioChart.js
│   │   │   ├── TradesTable.js
│   │   │   ├── TradesTable.css   # Table styles
│   │   ├── pages/               # Main pages
│   │   │   ├── Dashboard.js
│   │   ├── api.js               # API calls
│   │   ├── App.js               # Main App component
│   │   ├── index.js             # React root file
│   │   ├── styles/
│   │   │   ├── dashboard.css    # Dashboard styles
│   │   │   ├── index.css        # Global styles
│   ├── package.json             # Frontend dependencies
│   ├── .gitignore               # Ignore unnecessary files
│── submission.txt               # This file
│── requirements.txt             # Backend dependencies
│── CITATIONS.md                 # References and citations

---

## 🛠️ **Setup Instructions**
### 1️⃣ **Backend (FastAPI + ClickHouse)**
#### **Install dependencies**
```sh
pip install -r requirements.txt
